<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.themenate.net/enlink-bs/dist/login-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 22 Aug 2023 11:35:06 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Solor</title>

    <!-- Favicon -->
    

    <!-- page css -->

    <!-- Core css -->
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet">

</head>

<body>
    <div class="app">
        <div class="container-fluid p-h-0 p-v-20 bg full-height d-flex"
            style="background-image: url('assets/images/others/login-3.png')">
            <div class="d-flex flex-column justify-content-between w-100">
                <div class="container d-flex h-100">
                    <div class="row align-items-center w-100">
                        <div class="col-md-7 col-lg-5 m-h-auto">
                            <div class="card shadow-lg">
                                <div class="card-body">
                                    <div class="d-flex align-items-center justify-content-between m-b-30">
                                        <h1 class="img-fluid">Solor</h1>
                                        <h2 class="m-b-0">Sign In</h2>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('login')); ?>" id="adminLogin">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label class="font-weight-semibold" for="userName">Email:</label>
                                            <div class="input-affix">
                                                <i class="prefix-icon anticon anticon-user"></i>
                                                <input id="email" type="email"
                                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
                                            </div>
                                            <label for="email" class="error"
                                                style="display:none;color:red;"></label>
                                        </div>
                                        <div class="form-group">
                                            <label class="font-weight-semibold" for="password">Password:</label>
                                            
                                            <div class="input-affix m-b-10">
                                                <i class="prefix-icon anticon anticon-lock"></i>
                                                <input id="password" type="password"
                                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="password" placeholder="Password">
                                            </div>
                                            <label for="password" class="error"
                                                style="display:none;color:red;"></label>
                                        </div>
                                        <div class="form-group">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <button class="btn btn-primary">Sign In</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Core Vendors JS -->
    <script src="<?php echo e(asset('assets/js/vendors.min.js')); ?>"></script>

    <!-- page js -->

    <!-- Core JS -->
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script>
        $("#adminLogin").validate({
            rules: {
                email: {
                    required: true
                },
                password: {
                    required: true
                }
            },
            messages: {
                email: {
                    required: "Please enter email",
                },
                password: {
                    required: "Please enter password"
                }
            }
        });
    </script>

    <?php if(Session('info')): ?>
        <script>
            toastr.info('<?php echo e(Session('info')); ?>')
        </script>
    <?php endif; ?>
    <?php if(Session('success')): ?>
        <script>
            toastr.success('<?php echo e(Session('success')); ?>')
        </script>
    <?php endif; ?>
    <?php if(Session('error')): ?>
        <script>
            toastr.error('<?php echo e(Session('error')); ?>')
        </script>
    <?php endif; ?>


</body>


<!-- Mirrored from www.themenate.net/enlink-bs/dist/login-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 22 Aug 2023 11:35:17 GMT -->

</html>
<?php /**PATH D:\Xampp8\htdocs\solor\resources\views/auth/login.blade.php ENDPATH**/ ?>