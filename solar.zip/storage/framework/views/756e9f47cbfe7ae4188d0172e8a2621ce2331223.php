<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Solor</title>

    <!-- Favicon -->
    

    <!-- page css -->
    
    <link href="<?php echo e(asset('assets/vendors/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(asset('assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(asset('assets/vendors/select2/select2.css')); ?>" rel="stylesheet">
    <!-- Core css -->
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet">

    <style>
        .error {
            color: red;
        }
    </style>

</head>

<body>

    <?php
    $setting = App\Models\Cms::first();
    ?>

    <div class="app">
        <div class="layout">
            <!-- Header START -->
            <div class="header">
                <div class="logo logo-dark">
                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                        
                        <?php if(isset($setting)): ?>
                            <?php if(isset($setting->logo) && file_exists(public_path('Cms/Logo/' . $setting->logo))): ?>
                                <div class="mt-1">
                                    <img src="<?php echo e(asset('Cms/Logo/' . $setting->logo)); ?>" width="120px;" height="60px"
                                        alt="Logo">
                                    <img class="logo-fold" src="<?php echo e(asset('Cms/Logo/' . $setting->logo)); ?>"
                                        width="75px;" height="60px" alt="Logo">
                                </div>
                            <?php else: ?>
                                <h4 style="align-content: center;height: 65px;" class="custom">Solor</h4>
                            <?php endif; ?>
                        <?php else: ?>
                            <h4 style="align-content: center;height: 65px;" class="custom">Solor</h4>
                        <?php endif; ?>
                    </a>
                </div>
                <div class="nav-wrap">
                    <ul class="nav-left">
                        <li class="desktop-toggle">
                            <a href="javascript:void(0);">
                                <i class="anticon"></i>
                            </a>
                        </li>
                        <li class="mobile-toggle">
                            <a href="javascript:void(0);">
                                <i class="anticon"></i>
                            </a>
                        </li>
                    </ul>
                    <ul class="nav-right">
                        <li class="dropdown dropdown-animated scale-left">
                            <div class="pointer" data-toggle="dropdown">
                                <div class="avatar avatar-image  m-h-10 m-r-15">
                                    <img src="<?php echo e(asset('assets/images/avatars/profile_image.jpg')); ?>" alt="">
                                </div>
                            </div>
                            <div class="p-b-15 p-t-20 dropdown-menu pop-profile">
                                <div class="p-h-20 p-b-15 m-b-10 border-bottom">
                                    <div class="d-flex m-r-50">
                                        <div class="avatar avatar-lg avatar-image">
                                            <img src="<?php echo e(asset('assets/images/avatars/profile_image.jpg')); ?>" alt="">
                                        </div>
                                        <div class="m-l-10">
                                            <p class="m-b-0 text-dark font-weight-semibold">
                                                <?php echo e(isset(Auth::user()->name) ? ucfirst(Auth::user()->name) : ''); ?>

                                            </p>
                                            <p class="m-b-0 opacity-07">
                                                <?php echo e(isset(Auth::user()->phone_number) ? Auth::user()->phone_number : ''); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                                
                                <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                          document.getElementById('logout-form').submit();"
                                    class="dropdown-item d-block p-h-15 p-v-10">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <div>
                                            <i class="anticon opacity-04 font-size-16 anticon-logout"></i>
                                            <span class="m-l-10">Logout</span>
                                        </div>
                                        <i class="anticon font-size-10 anticon-right"></i>
                                    </div>
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Header END -->
<?php /**PATH D:\Xampp8\htdocs\solor\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>