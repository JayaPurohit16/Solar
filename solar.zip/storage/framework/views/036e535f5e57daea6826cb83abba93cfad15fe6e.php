<!-- Content Wrapper END -->

<!-- Footer START -->
<footer class="footer">
    <div class="footer-content">
        <p class="m-b-0">Copyright © <?php echo e(date('Y')); ?> Solor. All rights reserved.</p>
        <span>
            
        </span>
    </div>
</footer>
<!-- Footer END -->

</div>
<!-- Page Container END -->
</div>
</div>


<!-- Core Vendors JS -->
<script src="<?php echo e(asset('assets/js/vendors.min.js')); ?>"></script>

<!-- page js -->
<script src="<?php echo e(asset('assets/vendors/chartjs/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/dashboard-default.js')); ?>"></script>

<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

<script src="<?php echo e(asset('assets/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/datatables/dataTables.bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('.datepicker-input').datepicker({
            format: 'yyyy-mm-dd',
            todayHighlight: true
        });
    });
</script>

<script src="<?php echo e(asset('assets/vendors/select2/select2.min.js')); ?>"></script>
<script>
    $('.select2').select2();
</script>

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<?php if(Session('info')): ?>
    <script>
        toastr.info('<?php echo e(Session('info')); ?>')
    </script>
<?php endif; ?>
<?php if(Session('success')): ?>
    <script>
        toastr.success('<?php echo e(Session('success')); ?>')
    </script>
<?php endif; ?>
<?php if(Session('error')): ?>
    <script>
        toastr.error('<?php echo e(Session('error')); ?>')
    </script>
<?php endif; ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>

<!-- Core JS -->
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH D:\Xampp8\htdocs\solor\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>