<!-- Content Wrapper END -->

<!-- Footer START -->
<footer class="footer">
    <div class="footer-content">
        <p class="m-b-0">Copyright © {{ date('Y') }} Solor. All rights reserved.</p>
        <span>
            {{-- <a href="#" class="text-gray m-r-15">Term &amp; Conditions</a>
            <a href="#" class="text-gray">Privacy &amp; Policy</a> --}}
        </span>
    </div>
</footer>
<!-- Footer END -->

</div>
<!-- Page Container END -->
</div>
</div>


<!-- Core Vendors JS -->
<script src="{{ asset('assets/js/vendors.min.js') }}"></script>

<!-- page js -->
<script src="{{ asset('assets/vendors/chartjs/Chart.min.js') }}"></script>
<script src="{{ asset('assets/js/pages/dashboard-default.js') }}"></script>
{{-- Validation JS --}}
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
{{-- Data Table JS --}}
<script src="{{ asset('assets/vendors/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/vendors/datatables/dataTables.bootstrap.min.js') }}"></script>
{{-- Date Picker JS --}}
<script src="{{ asset('assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js') }}"></script>
<script>
    $(document).ready(function() {
        $('.datepicker-input').datepicker({
            format: 'yyyy-mm-dd',
            todayHighlight: true
        });
    });
</script>
{{-- Select 2 JS --}}
<script src="{{ asset('assets/vendors/select2/select2.min.js') }}"></script>
<script>
    $('.select2').select2();
</script>
{{-- Ck Edit JS --}}
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
{{-- Toastr Link --}}
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- Toastr JS --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
@if (Session('info'))
    <script>
        toastr.info('{{ Session('info') }}')
    </script>
@endif
@if (Session('success'))
    <script>
        toastr.success('{{ Session('success') }}')
    </script>
@endif
@if (Session('error'))
    <script>
        toastr.error('{{ Session('error') }}')
    </script>
@endif
{{-- Sweet Alert JS --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>

<!-- Core JS -->
<script src="{{ asset('assets/js/app.min.js') }}"></script>

</body>

</html>
